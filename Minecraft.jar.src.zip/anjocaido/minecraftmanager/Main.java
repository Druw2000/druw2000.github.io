/*    */ package anjocaido.minecraftmanager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 25 */     new MinecraftBackupManager().setVisible(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\anjocaido\minecraftmanager\Main.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */