/*     */ package anjocaido.minecraftmanager;
/*     */ 
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JRadioButton;
/*     */ 
/*     */ public class MinecraftBackupManager extends javax.swing.JFrame
/*     */ {
/*     */   private JButton backupgame;
/*     */   private javax.swing.JCheckBox fullgamebackup;
/*     */   private JButton jButton1;
/*     */   private JButton jButton2;
/*     */   private JButton jButton5;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel10;
/*     */   private JLabel jLabel12;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   
/*     */   public MinecraftBackupManager()
/*     */   {
/*     */     try
/*     */     {
/*  33 */       javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}catch (InstantiationException ex) {}catch (IllegalAccessException ex) {}catch (javax.swing.UnsupportedLookAndFeelException ex) {}
/*     */     
/*     */ 
/*     */ 
/*  39 */     initComponents();
/*  40 */     refreshButtons();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  52 */     this.worldgroup = new javax.swing.ButtonGroup();
/*  53 */     this.jTabbedPane1 = new javax.swing.JTabbedPane();
/*  54 */     this.jPanel1 = new javax.swing.JPanel();
/*  55 */     this.jPanel3 = new javax.swing.JPanel();
/*  56 */     this.world1 = new JRadioButton();
/*  57 */     this.world2 = new JRadioButton();
/*  58 */     this.world3 = new JRadioButton();
/*  59 */     this.world4 = new JRadioButton();
/*  60 */     this.world5 = new JRadioButton();
/*  61 */     this.jPanel4 = new javax.swing.JPanel();
/*  62 */     this.jButton1 = new JButton();
/*  63 */     this.jButton2 = new JButton();
/*  64 */     this.jLabel3 = new JLabel();
/*  65 */     this.jLabel4 = new JLabel();
/*  66 */     this.jLabel5 = new JLabel();
/*  67 */     this.jLabel6 = new JLabel();
/*  68 */     this.jLabel10 = new JLabel();
/*  69 */     this.jPanel2 = new javax.swing.JPanel();
/*  70 */     this.uninstall = new JButton();
/*  71 */     this.saveuninstall = new javax.swing.JCheckBox();
/*  72 */     this.backupgame = new JButton();
/*  73 */     this.jButton5 = new JButton();
/*  74 */     this.jLabel1 = new JLabel();
/*  75 */     this.jLabel2 = new JLabel();
/*  76 */     this.jLabel7 = new JLabel();
/*  77 */     this.fullgamebackup = new javax.swing.JCheckBox();
/*  78 */     this.jSeparator1 = new javax.swing.JSeparator();
/*  79 */     this.jLabel8 = new JLabel();
/*  80 */     this.jLabel12 = new JLabel();
/*     */     
/*  82 */     setDefaultCloseOperation(2);
/*  83 */     setTitle("Minecraft Backup Manager (by AnjoCaido)");
/*     */     
/*  85 */     this.worldgroup.add(this.world1);
/*  86 */     this.world1.setForeground(new java.awt.Color(255, 0, 0));
/*  87 */     this.world1.setText("World 1");
/*     */     
/*  89 */     this.worldgroup.add(this.world2);
/*  90 */     this.world2.setForeground(new java.awt.Color(255, 0, 0));
/*  91 */     this.world2.setText("World 2");
/*     */     
/*  93 */     this.worldgroup.add(this.world3);
/*  94 */     this.world3.setForeground(new java.awt.Color(255, 0, 0));
/*  95 */     this.world3.setText("World 3");
/*     */     
/*  97 */     this.worldgroup.add(this.world4);
/*  98 */     this.world4.setForeground(new java.awt.Color(255, 0, 0));
/*  99 */     this.world4.setText("World 4");
/*     */     
/* 101 */     this.worldgroup.add(this.world5);
/* 102 */     this.world5.setForeground(new java.awt.Color(255, 0, 0));
/* 103 */     this.world5.setText("World 5");
/*     */     
/* 105 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 106 */     this.jPanel3.setLayout(jPanel3Layout);
/* 107 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.world1).addComponent(this.world2).addComponent(this.world3).addComponent(this.world4).addComponent(this.world5)).addContainerGap(-1, 32767)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addComponent(this.world1).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.world2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.world3).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.world4).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.world5).addContainerGap(-1, 32767)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     this.jButton1.setText("Do Backup");
/* 136 */     this.jButton1.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/* 138 */         MinecraftBackupManager.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */       
/* 141 */     });
/* 142 */     this.jButton2.setText("Restore Backup");
/* 143 */     this.jButton2.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/* 145 */         MinecraftBackupManager.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */       
/* 148 */     });
/* 149 */     GroupLayout jPanel4Layout = new GroupLayout(this.jPanel4);
/* 150 */     this.jPanel4.setLayout(jPanel4Layout);
/* 151 */     jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup().addContainerGap().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jButton2, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jButton1, GroupLayout.Alignment.LEADING, -1, 118, 32767)).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */     jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addContainerGap().addComponent(this.jButton1).addGap(18, 18, 18).addComponent(this.jButton2).addContainerGap(-1, 32767)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */     this.jLabel3.setText("Everything will be stored in a Zip format.");
/*     */     
/* 172 */     this.jLabel4.setText("But I will use .mcworld extension,  cuz that makes me happy.");
/*     */     
/* 174 */     this.jLabel5.setText("You can restore any previous world number, to any world number you desire.");
/*     */     
/* 176 */     this.jLabel6.setText("Ex: You create a backup of World 2, but then you can restore it to World 1.");
/*     */     
/* 178 */     this.jLabel10.setForeground(new java.awt.Color(255, 0, 0));
/* 179 */     this.jLabel10.setText("RED color marks the Worlds you don't have!");
/*     */     
/* 181 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 182 */     this.jPanel1.setLayout(jPanel1Layout);
/* 183 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jPanel3, -2, -1, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(6, 6, 6).addComponent(this.jPanel4, -2, -1, -2)).addComponent(this.jLabel10).addComponent(this.jLabel3))).addComponent(this.jLabel4).addComponent(this.jLabel5).addComponent(this.jLabel6)).addContainerGap(109, 32767)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel3, -2, -1, -2).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel10).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel4, -2, -1, -2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jLabel3))).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel4).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel5).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel6).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 223 */     this.jTabbedPane1.addTab("Game Saves", this.jPanel1);
/*     */     
/* 225 */     this.uninstall.setText("Uninstall Game");
/* 226 */     this.uninstall.setEnabled(false);
/* 227 */     this.uninstall.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/* 229 */         MinecraftBackupManager.this.uninstallActionPerformed(evt);
/*     */       }
/*     */       
/* 232 */     });
/* 233 */     this.saveuninstall.setText("Complete Uninstall (Include Game Saves/Worlds)");
/* 234 */     this.saveuninstall.setEnabled(false);
/*     */     
/* 236 */     this.backupgame.setText("Backup Game (Binaries)");
/* 237 */     this.backupgame.setEnabled(false);
/* 238 */     this.backupgame.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/* 240 */         MinecraftBackupManager.this.backupgameActionPerformed(evt);
/*     */       }
/*     */       
/* 243 */     });
/* 244 */     this.jButton5.setText("Restore Game");
/* 245 */     this.jButton5.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/* 247 */         MinecraftBackupManager.this.jButton5ActionPerformed(evt);
/*     */       }
/*     */       
/* 250 */     });
/* 251 */     this.jLabel1.setText("You might want to backup the whole game at least once after it's installed.");
/*     */     
/* 253 */     this.jLabel2.setText("Never know when there is an update out there that breaks everything.");
/*     */     
/* 255 */     this.jLabel7.setText("Zip format again, but .mcgame extension. It really makes me happy.");
/*     */     
/* 257 */     this.fullgamebackup.setText("Entire Folder (Inc. Saves or any other file there)");
/* 258 */     this.fullgamebackup.setEnabled(false);
/* 259 */     this.fullgamebackup.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent evt) {
/* 261 */         MinecraftBackupManager.this.fullgamebackupActionPerformed(evt);
/*     */       }
/*     */       
/* 264 */     });
/* 265 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 266 */     this.jPanel2.setLayout(jPanel2Layout);
/* 267 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGap(6, 6, 6).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel2).addComponent(this.jLabel7).addComponent(this.jLabel1))).addComponent(this.jSeparator1, -1, 551, 32767).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.uninstall).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.saveuninstall)).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.backupgame).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.fullgamebackup)).addComponent(this.jButton5, -2, 239, -2)).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 290 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.uninstall).addComponent(this.saveuninstall)).addGap(3, 3, 3).addComponent(this.jSeparator1, -2, 10, -2).addGap(18, 18, 18).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.backupgame).addComponent(this.fullgamebackup)).addGap(18, 18, 18).addComponent(this.jButton5).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel2).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel7).addContainerGap(-1, 32767)));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */     this.jTabbedPane1.addTab("Game Installation", this.jPanel2);
/*     */     
/* 316 */     this.jLabel8.setText("by AnjoCaido - v1.1");
/*     */     
/* 318 */     this.jLabel12.setText("Backup/Restore take some seconds, wait for \"Done!\".");
/*     */     
/* 320 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 321 */     getContentPane().setLayout(layout);
/* 322 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jTabbedPane1, GroupLayout.Alignment.LEADING, -1, 563, 32767).addGroup(layout.createSequentialGroup().addComponent(this.jLabel12).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 137, 32767).addComponent(this.jLabel8))).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 334 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addContainerGap().addComponent(this.jTabbedPane1, -1, 234, 32767).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel8).addComponent(this.jLabel12)).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 346 */     pack();
/*     */   }
/*     */   
/*     */   private void uninstallActionPerformed(java.awt.event.ActionEvent evt) {
/* 350 */     int result = javax.swing.JOptionPane.showConfirmDialog(this, "Are you sure that you want to uninstall Minecraft?\nCan't Undo It! (unless you have backup, hehe)", "Are you sure? (Uninstallation)", 0, 2);
/*     */     
/* 352 */     if ((result == 1) || (result == -1)) {
/* 353 */       return;
/*     */     }
/* 355 */     BackupUtil.uninstallGame(this.saveuninstall.isSelected());
/* 356 */     javax.swing.JOptionPane.showMessageDialog(this, "Done!", "Uninstallation", -1);
/* 357 */     refreshButtons();
/*     */   }
/*     */   
/*     */   private void backupgameActionPerformed(java.awt.event.ActionEvent evt) {
/* 361 */     JFileChooser save = new JFileChooser();
/* 362 */     java.util.Calendar now = java.util.GregorianCalendar.getInstance();
/* 363 */     save.setSelectedFile(new java.io.File(String.format("MCGame_" + (this.fullgamebackup.isSelected() ? "Complete_" : "") + "%1$tY-%1$tm-%1$td_%1$tH-%1$tM-%1$tS" + "_Backup." + "mcgame", new Object[] { now })));
/* 364 */     save.setFileSelectionMode(0);
/* 365 */     save.setFileFilter(new BackupUtil.GameFileFilter());
/* 366 */     int result = save.showSaveDialog(this);
/* 367 */     if (result != 0) {
/* 368 */       return;
/*     */     }
/* 370 */     java.io.File f = save.getSelectedFile();
/* 371 */     if (f == null) {
/* 372 */       return;
/*     */     }
/* 374 */     BackupUtil.backupGame(f, this.fullgamebackup.isSelected());
/* 375 */     javax.swing.JOptionPane.showMessageDialog(this, "Done!", "Game Backup", -1);
/*     */   }
/*     */   
/*     */   private void jButton5ActionPerformed(java.awt.event.ActionEvent evt)
/*     */   {
/* 380 */     int result = javax.swing.JOptionPane.showConfirmDialog(this, "Are you sure that you want to restore WHOLE Minecraft?\nIT MIGHT OVERWRITE ALL YOUR DATA\n(if is a complete backup, you'll lose all your actual worlds/saves!)\nMake sure you have your most recent save games backed up before this!", "Are you sure? (Full Game Restoration)", 0, 2);
/*     */     
/*     */ 
/*     */ 
/* 384 */     if ((result == 1) || (result == -1)) {
/* 385 */       return;
/*     */     }
/* 387 */     JFileChooser save = new JFileChooser();
/* 388 */     save.setFileSelectionMode(0);
/* 389 */     save.setFileFilter(new BackupUtil.GameFileFilter());
/* 390 */     save.showOpenDialog(this);
/* 391 */     java.io.File f = save.getSelectedFile();
/* 392 */     if ((f == null) || (!f.exists())) {
/* 393 */       return;
/*     */     }
/*     */     try {
/* 396 */       BackupUtil.restoreGame(f);
/*     */     } catch (IllegalStateException ex) {
/* 398 */       javax.swing.JOptionPane.showMessageDialog(this, "Failed!\nInvalid Zip Contents!\nthe game folder inside must have 'minecraft_backup' as name.", "Game Restoration", 0);
/*     */       
/*     */ 
/* 401 */       return;
/*     */     }
/* 403 */     javax.swing.JOptionPane.showMessageDialog(this, "Done!", "Game Restoration", -1);
/* 404 */     refreshButtons();
/*     */   }
/*     */   
/*     */   private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
/* 408 */     int world = getWorldSelected();
/* 409 */     if (world < 0) {
/* 410 */       javax.swing.JOptionPane.showMessageDialog(this, "Error. Please Select a World to Backup first!", "World Backup", 0);
/* 411 */       return;
/*     */     }
/* 413 */     if (!BackupUtil.getWorldNFolder(world).exists()) {
/* 414 */       javax.swing.JOptionPane.showMessageDialog(this, "Sorry, but this world doesn't Exist!", "World Backup", 0);
/* 415 */       return;
/*     */     }
/* 417 */     JFileChooser save = new JFileChooser();
/* 418 */     java.util.Calendar now = java.util.GregorianCalendar.getInstance();
/* 419 */     save.setFileSelectionMode(0);
/* 420 */     save.setSelectedFile(new java.io.File(String.format("MCWorld" + world + "_" + "%1$tY-%1$tm-%1$td_%1$tH-%1$tM-%1$tS" + "_Backup." + "mcworld", new Object[] { now })));
/*     */     
/* 422 */     save.setFileFilter(new BackupUtil.WorldFileFilter());
/* 423 */     int result = save.showSaveDialog(this);
/* 424 */     if (result != 0) {
/* 425 */       return;
/*     */     }
/* 427 */     java.io.File f = save.getSelectedFile();
/* 428 */     if (f == null) {
/* 429 */       return;
/*     */     }
/* 431 */     BackupUtil.backupWorld(world, f);
/* 432 */     javax.swing.JOptionPane.showMessageDialog(this, "Done!", "World Backup", -1);
/*     */   }
/*     */   
/*     */   private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
/* 436 */     int world = getWorldSelected();
/* 437 */     if (world < 0) {
/* 438 */       javax.swing.JOptionPane.showMessageDialog(this, "Error. Please Select a World to Restore first!", "World Restoration", 0);
/* 439 */       return;
/*     */     }
/* 441 */     if (BackupUtil.getWorldNFolder(world).exists()) {
/* 442 */       int result = javax.swing.JOptionPane.showConfirmDialog(this, "Are you sure that you want to overwrite World " + world + "?\n" + "Can't Undo It! (unless you have backup, hehe)", "Are you sure? (World Restoration)", 0, 2);
/*     */       
/* 444 */       if ((result == 1) || (result == -1)) {
/* 445 */         return;
/*     */       }
/*     */     }
/*     */     
/* 449 */     JFileChooser save = new JFileChooser();
/* 450 */     save.setFileSelectionMode(0);
/* 451 */     save.setFileFilter(new BackupUtil.WorldFileFilter());
/* 452 */     save.showOpenDialog(this);
/* 453 */     java.io.File f = save.getSelectedFile();
/* 454 */     if (f == null) {
/* 455 */       return;
/*     */     }
/*     */     try {
/* 458 */       BackupUtil.restoreWorld(world, f);
/*     */     } catch (IllegalStateException ex) {
/* 460 */       javax.swing.JOptionPane.showMessageDialog(this, "Failed!\nInvalid Zip Contents!\nthe world folder inside must have 'world_backup' as name.", "World Restoration", 0);
/*     */       
/*     */ 
/* 463 */       return;
/*     */     }
/* 465 */     javax.swing.JOptionPane.showMessageDialog(this, "Done!", "World Restoration", -1);
/* 466 */     refreshButtons();
/*     */   }
/*     */   
/*     */   private void fullgamebackupActionPerformed(java.awt.event.ActionEvent evt) {
/* 470 */     if (this.fullgamebackup.isSelected()) {
/* 471 */       this.backupgame.setText("Backup Game (Complete)");
/*     */     } else {
/* 473 */       this.backupgame.setText("Backup Game (Binaries)");
/*     */     }
/*     */   }
/*     */   
/*     */   public int getWorldSelected() {
/* 478 */     if (this.world1.isSelected()) {
/* 479 */       return 1;
/*     */     }
/* 481 */     if (this.world2.isSelected()) {
/* 482 */       return 2;
/*     */     }
/* 484 */     if (this.world3.isSelected()) {
/* 485 */       return 3;
/*     */     }
/* 487 */     if (this.world4.isSelected()) {
/* 488 */       return 4;
/*     */     }
/* 490 */     if (this.world5.isSelected()) {
/* 491 */       return 5;
/*     */     }
/* 493 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 500 */     java.awt.EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 503 */         new MinecraftBackupManager().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private JLabel jLabel8;
/*     */   
/*     */   private javax.swing.JPanel jPanel1;
/*     */   
/*     */   private javax.swing.JPanel jPanel2;
/*     */   
/*     */   private javax.swing.JPanel jPanel3;
/*     */   
/*     */   private javax.swing.JPanel jPanel4;
/*     */   
/*     */   private javax.swing.JSeparator jSeparator1;
/*     */   
/*     */   private javax.swing.JTabbedPane jTabbedPane1;
/*     */   
/*     */   private javax.swing.JCheckBox saveuninstall;
/*     */   
/*     */   private JButton uninstall;
/*     */   
/*     */   private JRadioButton world1;
/*     */   
/*     */   private JRadioButton world2;
/*     */   
/*     */   private JRadioButton world3;
/*     */   
/*     */   private JRadioButton world4;
/*     */   
/*     */   private JRadioButton world5;
/*     */   
/*     */   private javax.swing.ButtonGroup worldgroup;
/*     */   
/*     */   private void refreshButtons()
/*     */   {
/* 542 */     if (BackupUtil.getWorldNFolder(1).exists()) {
/* 543 */       this.world1.setForeground(java.awt.Color.BLACK);
/*     */     } else {
/* 545 */       this.world1.setForeground(java.awt.Color.RED);
/*     */     }
/* 547 */     if (BackupUtil.getWorldNFolder(2).exists()) {
/* 548 */       this.world2.setForeground(java.awt.Color.BLACK);
/*     */     } else {
/* 550 */       this.world2.setForeground(java.awt.Color.RED);
/*     */     }
/* 552 */     if (BackupUtil.getWorldNFolder(3).exists()) {
/* 553 */       this.world3.setForeground(java.awt.Color.BLACK);
/*     */     } else {
/* 555 */       this.world3.setForeground(java.awt.Color.RED);
/*     */     }
/* 557 */     if (BackupUtil.getWorldNFolder(4).exists()) {
/* 558 */       this.world4.setForeground(java.awt.Color.BLACK);
/*     */     } else {
/* 560 */       this.world4.setForeground(java.awt.Color.RED);
/*     */     }
/* 562 */     if (BackupUtil.getWorldNFolder(5).exists()) {
/* 563 */       this.world5.setForeground(java.awt.Color.BLACK);
/*     */     } else {
/* 565 */       this.world5.setForeground(java.awt.Color.RED);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 570 */     if ((net.minecraft.MinecraftUtil.getBinFolder().exists()) || (net.minecraft.MinecraftUtil.getLoginFile().exists()) || (net.minecraft.MinecraftUtil.getOptionsFile().exists()) || (net.minecraft.MinecraftUtil.getResourcesFolder().exists()) || (net.minecraft.MinecraftUtil.getSavesFolder().exists())) {
/* 571 */       this.uninstall.setEnabled(true);
/*     */     } else {
/* 573 */       this.uninstall.setEnabled(false);
/*     */     }
/*     */     
/* 576 */     if (net.minecraft.MinecraftUtil.getSavesFolder().exists()) {
/* 577 */       this.saveuninstall.setEnabled(true);
/*     */     } else {
/* 579 */       this.saveuninstall.setEnabled(false);
/*     */     }
/*     */     
/*     */ 
/* 583 */     if (net.minecraft.MinecraftUtil.getBinFolder().exists()) {
/* 584 */       this.backupgame.setEnabled(true);
/* 585 */       this.fullgamebackup.setEnabled(true);
/*     */     } else {
/* 587 */       this.backupgame.setEnabled(false);
/* 588 */       this.fullgamebackup.setEnabled(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\anjocaido\minecraftmanager\MinecraftBackupManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */