/*     */ package anjocaido.minecraftmanager;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import net.minecraft.MinecraftUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BackupUtil
/*     */ {
/*     */   public static final String WORLD_BACKUP_EXTENSION = "mcworld";
/*     */   public static final String WORLD_BACKUP_GEN_NAME = "world_backup";
/*     */   public static final String GAME_BACKUP_EXTENSION = "mcgame";
/*     */   public static final String GAME_BACKUP_GEN_NAME = "minecraft_backup";
/*     */   public static final String DATE_TIME_FORMAT = "%1$tY-%1$tm-%1$td_%1$tH-%1$tM-%1$tS";
/*     */   
/*     */   public static void uninstallGame(boolean includeSaves)
/*     */   {
/*  22 */     deleteFileDir(MinecraftUtil.getBinFolder());
/*  23 */     deleteFileDir(MinecraftUtil.getLoginFile());
/*  24 */     deleteFileDir(MinecraftUtil.getResourcesFolder());
/*  25 */     deleteFileDir(MinecraftUtil.getOptionsFile());
/*  26 */     if (includeSaves)
/*  27 */       deleteFileDir(MinecraftUtil.getSavesFolder());
/*     */   }
/*     */   
/*     */   public static void backupGame(File zipDestiny, boolean wholegame) {
/*     */     File[] source;
/*     */     File[] source;
/*  33 */     if (!wholegame) {
/*  34 */       ArrayList<File> contents = new ArrayList();
/*     */       
/*  36 */       File f = MinecraftUtil.getBinFolder();
/*  37 */       if (f.exists()) {
/*  38 */         contents.add(f);
/*     */       }
/*  40 */       f = MinecraftUtil.getResourcesFolder();
/*  41 */       if (f.exists()) {
/*  42 */         contents.add(f);
/*     */       }
/*  44 */       f = MinecraftUtil.getLoginFile();
/*  45 */       if (f.exists()) {
/*  46 */         contents.add(f);
/*     */       }
/*  48 */       f = MinecraftUtil.getOptionsFile();
/*  49 */       if (f.exists()) {
/*  50 */         contents.add(f);
/*     */       }
/*  52 */       source = (File[])contents.toArray(new File[contents.size()]);
/*     */     } else {
/*  54 */       source = MinecraftUtil.getWorkingDirectory().listFiles();
/*     */     }
/*  56 */     backupContents(source, zipDestiny, "minecraft_backup", "mcgame");
/*     */   }
/*     */   
/*     */   public static void restoreGame(File zipSource) {
/*  60 */     File destiny = MinecraftUtil.getWorkingDirectory();
/*  61 */     restoreContents(zipSource, destiny, "minecraft_backup");
/*     */   }
/*     */   
/*     */   public static File getWorldNFolder(int n) {
/*  65 */     File source = new File(MinecraftUtil.getSavesFolder(), "World" + n);
/*  66 */     return source;
/*     */   }
/*     */   
/*     */   public static void backupWorld(int n, File destZip) {
/*  70 */     File source = getWorldNFolder(n);
/*  71 */     backupFile(source, destZip, "world_backup", "mcworld");
/*     */   }
/*     */   
/*     */   public static void restoreWorld(int n, File zipSource) {
/*  75 */     File destiny = getWorldNFolder(n);
/*  76 */     restoreFile(zipSource, destiny, "world_backup");
/*     */   }
/*     */   
/*     */   public static void backupFile(File source, File zipDestiny, String genericName, String extension) {
/*  80 */     File generic = new File(MinecraftUtil.getTempFolder(), genericName);
/*  81 */     if (!source.exists()) {
/*  82 */       throw new IllegalArgumentException("Source file does not exist: " + source.getName());
/*     */     }
/*  84 */     if (!zipDestiny.getName().endsWith("." + extension)) {
/*  85 */       zipDestiny = new File(zipDestiny.getPath() + "." + extension);
/*     */     }
/*  87 */     if (generic.exists()) {
/*  88 */       deleteFileDir(generic);
/*     */     }
/*  90 */     source.renameTo(generic);
/*  91 */     Zipper.zipFolder(generic, zipDestiny);
/*  92 */     generic.renameTo(source);
/*     */   }
/*     */   
/*     */   public static String getExtension(File f) {
/*  96 */     String ext = null;
/*  97 */     String s = f.getName();
/*  98 */     int i = s.lastIndexOf('.');
/*     */     
/* 100 */     if ((i > 0) && (i < s.length() - 1)) {
/* 101 */       ext = s.substring(i + 1).toLowerCase();
/*     */     }
/* 103 */     return ext;
/*     */   }
/*     */   
/*     */   public static boolean deleteFileDir(File dir) {
/* 107 */     if (!dir.exists()) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (dir.isFile())
/* 111 */       return dir.delete();
/* 112 */     if (dir.isDirectory()) {
/* 113 */       for (File f : dir.listFiles()) {
/* 114 */         deleteFileDir(f);
/*     */       }
/* 116 */       return dir.delete();
/*     */     }
/* 118 */     return dir.delete();
/*     */   }
/*     */   
/*     */   public static void restoreFile(File zipSource, File destiny, String genericName) {
/* 122 */     File generic = new File(MinecraftUtil.getTempFolder(), genericName);
/* 123 */     if (generic.exists()) {
/* 124 */       deleteFileDir(generic);
/*     */     }
/* 126 */     Zipper.unzipFolder(zipSource, MinecraftUtil.getTempFolder());
/* 127 */     if (!generic.exists()) {
/* 128 */       throw new IllegalStateException("Wrong content in zip file -> not found: " + generic.getName());
/*     */     }
/* 130 */     if (destiny.exists()) {
/* 131 */       deleteFileDir(destiny);
/*     */     }
/* 133 */     if ((destiny.getParentFile() != null) && (!destiny.getParentFile().exists())) {
/* 134 */       destiny.getParentFile().mkdirs();
/*     */     }
/* 136 */     generic.renameTo(destiny);
/*     */   }
/*     */   
/*     */   public static void backupContents(File[] folderContents, File zipDestiny, String genericName, String extension) {
/* 140 */     for (File content : folderContents) {
/* 141 */       if (!content.exists()) {
/* 142 */         throw new IllegalArgumentException("You sent me a folder content that doesnt exist : " + content.getName());
/*     */       }
/*     */     }
/*     */     
/* 146 */     if (!zipDestiny.getName().endsWith("." + extension)) {
/* 147 */       zipDestiny = new File(zipDestiny.getPath() + "." + extension);
/*     */     }
/* 149 */     Zipper.zipFolders(folderContents, zipDestiny, genericName);
/*     */   }
/*     */   
/*     */   public static void restoreContents(File zipSource, File folderDestiny, String genericName) {
/* 153 */     File genericFolder = new File(MinecraftUtil.getTempFolder(), genericName);
/* 154 */     if (genericFolder.exists()) {
/* 155 */       deleteFileDir(genericFolder);
/*     */     }
/* 157 */     if (!folderDestiny.exists()) {
/* 158 */       folderDestiny.mkdirs();
/*     */     }
/* 160 */     if (!folderDestiny.isDirectory()) {
/* 161 */       throw new IllegalArgumentException("The destiny folder must be a directory!");
/*     */     }
/* 163 */     Zipper.unzipFolder(zipSource, MinecraftUtil.getTempFolder());
/* 164 */     if (!genericFolder.exists()) {
/* 165 */       throw new IllegalStateException("Wrong content in zip file -> not found: " + genericFolder.getName());
/*     */     }
/* 167 */     File[] generics = genericFolder.listFiles();
/* 168 */     for (File generic : generics) {
/* 169 */       File destiny = new File(folderDestiny, generic.getName());
/* 170 */       if (destiny.exists()) {
/* 171 */         deleteFileDir(destiny);
/*     */       }
/* 173 */       generic.renameTo(destiny);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WorldFileFilter extends FileFilter
/*     */   {
/*     */     public boolean accept(File f) {
/* 180 */       if (f == null) {
/* 181 */         return false;
/*     */       }
/* 183 */       if (f.isDirectory()) {
/* 184 */         return true;
/*     */       }
/* 186 */       String ext = BackupUtil.getExtension(f);
/* 187 */       if ((ext != null) && (ext.equalsIgnoreCase("mcworld"))) {
/* 188 */         return true;
/*     */       }
/* 190 */       return false;
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 195 */       return "Minecraft World files";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GameFileFilter extends FileFilter
/*     */   {
/*     */     public boolean accept(File f)
/*     */     {
/* 203 */       if (f == null) {
/* 204 */         return false;
/*     */       }
/* 206 */       if (f.isDirectory()) {
/* 207 */         return true;
/*     */       }
/* 209 */       String ext = BackupUtil.getExtension(f);
/* 210 */       if ((ext != null) && (ext.equalsIgnoreCase("mcgame"))) {
/* 211 */         return true;
/*     */       }
/* 213 */       return false;
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 218 */       return "Minecraft Game files";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\anjocaido\minecraftmanager\BackupUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */