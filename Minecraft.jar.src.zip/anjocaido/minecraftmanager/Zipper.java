/*     */ package anjocaido.minecraftmanager;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Zipper
/*     */ {
/*     */   static final int BUFFER = 2048;
/*     */   
/*     */   public static boolean zipFolders(File[] srcFolders, File destZipFile)
/*     */   {
/*  32 */     return zipFolders(srcFolders, destZipFile, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean zipFolders(File[] srcFolders, File destZipFile, String inFolderName)
/*     */   {
/*     */     try
/*     */     {
/*  41 */       BufferedInputStream origin = null;
/*  42 */       FileOutputStream dest = new FileOutputStream(destZipFile);
/*  43 */       ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(dest));
/*     */       
/*  45 */       for (File fileFolder : srcFolders) {
/*  46 */         if (!addToZip(fileFolder.getParentFile().getPath(), inFolderName, fileFolder.getName(), out)) {
/*  47 */           return false;
/*     */         }
/*     */       }
/*     */       
/*  51 */       out.close();
/*     */     } catch (Exception e) {
/*  53 */       e.printStackTrace();
/*     */     }
/*  55 */     return true;
/*     */   }
/*     */   
/*     */   protected static boolean addToZip(String absolutePath, String relativePath, String fileName, ZipOutputStream out) {
/*  59 */     File file = new File(absolutePath + File.separator + fileName);
/*     */     
/*  61 */     System.out.println("Adding \"" + absolutePath + File.separator + fileName + "\" file");
/*  62 */     if (file.isHidden())
/*  63 */       return true;
/*  64 */     if (file.isDirectory()) {
/*  65 */       absolutePath = absolutePath + File.separator + file.getName();
/*  66 */       relativePath = relativePath + File.separator + file.getName();
/*  67 */       for (String child : file.list()) {
/*  68 */         if (!addToZip(absolutePath, relativePath, child, out)) {
/*  69 */           return false;
/*     */         }
/*     */       }
/*  72 */       return true;
/*     */     }
/*     */     try {
/*  75 */       byte[] data = new byte['ࠀ'];
/*     */       
/*  77 */       FileInputStream fi = new FileInputStream(file);
/*  78 */       BufferedInputStream origin = new BufferedInputStream(fi, 2048);
/*  79 */       ZipEntry entry = new ZipEntry(relativePath + File.separator + fileName);
/*  80 */       out.putNextEntry(entry);
/*     */       int count;
/*  82 */       while ((count = origin.read(data, 0, 2048)) != -1) {
/*  83 */         out.write(data, 0, count);
/*     */       }
/*  85 */       origin.close();
/*     */     } catch (Exception ex) {
/*  87 */       Logger.getLogger(Zipper.class.getName()).log(Level.SEVERE, null, ex);
/*  88 */       return false;
/*     */     }
/*  90 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean zipFolder(File srcFolder, File destZipFile)
/*     */   {
/*  98 */     File[] ar = new File[1];
/*  99 */     ar[0] = srcFolder;
/* 100 */     return zipFolders(ar, destZipFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unzipFolder(File zipFile, File destFolder)
/*     */   {
/*     */     try
/*     */     {
/* 110 */       BufferedOutputStream dest = null;
/* 111 */       FileInputStream fis = new FileInputStream(zipFile);
/* 112 */       ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
/*     */       ZipEntry entry;
/* 114 */       while ((entry = zis.getNextEntry()) != null) {
/* 115 */         System.out.println("Extracting: " + entry);
/*     */         
/* 117 */         byte[] data = new byte['ࠀ'];
/*     */         
/* 119 */         File f = new File(destFolder + File.separator + entry.getName());
/* 120 */         if ((f.getParentFile() != null) && (!f.getParentFile().exists())) {
/* 121 */           f.getParentFile().mkdirs();
/*     */         }
/* 123 */         if (!f.exists())
/*     */         {
/* 125 */           f.createNewFile();
/* 126 */           f.getParent();
/*     */         }
/* 128 */         FileOutputStream fos = new FileOutputStream(f);
/* 129 */         dest = new BufferedOutputStream(fos, 2048);
/*     */         int count;
/* 131 */         while ((count = zis.read(data, 0, 2048)) != -1) {
/* 132 */           dest.write(data, 0, count);
/*     */         }
/* 134 */         dest.flush();
/* 135 */         dest.close();
/*     */       }
/* 137 */       zis.close();
/*     */     } catch (Exception e) {
/* 139 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\anjocaido\minecraftmanager\Zipper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */