/*     */ package anjocaido.console;
/*     */ 
/*     */ import java.awt.Adjustable;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.AdjustmentEvent;
/*     */ import java.awt.event.AdjustmentListener;
/*     */ import javax.swing.DropMode;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputConsole
/*     */   extends JFrame
/*     */ {
/*  24 */   int threadsUsing = 0;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTextArea jTextArea1;
/*     */   
/*  28 */   public OutputConsole() { initComponents();
/*  29 */     this.jScrollPane1.getVerticalScrollBar().addAdjustmentListener(new AdjustmentListener()
/*     */     {
/*     */       public void adjustmentValueChanged(AdjustmentEvent e) {
/*  32 */         e.getAdjustable().setValue(e.getAdjustable().getMaximum());
/*     */       }
/*  34 */     });
/*  35 */     pack();
/*  36 */     setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  48 */     this.jScrollPane1 = new JScrollPane();
/*  49 */     this.jTextArea1 = new JTextArea();
/*     */     
/*  51 */     setDefaultCloseOperation(2);
/*  52 */     setTitle("Error Console");
/*     */     
/*  54 */     this.jScrollPane1.setAutoscrolls(true);
/*  55 */     this.jScrollPane1.setColumnHeaderView(null);
/*  56 */     this.jScrollPane1.setCursor(new Cursor(0));
/*  57 */     this.jScrollPane1.setDebugGraphicsOptions(-1);
/*     */     
/*  59 */     this.jTextArea1.setColumns(20);
/*  60 */     this.jTextArea1.setEditable(false);
/*  61 */     this.jTextArea1.setRows(5);
/*  62 */     this.jTextArea1.setDropMode(DropMode.INSERT);
/*  63 */     this.jScrollPane1.setViewportView(this.jTextArea1);
/*     */     
/*  65 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  66 */     getContentPane().setLayout(layout);
/*  67 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -1, 636, 32767).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -1, 227, 32767).addContainerGap()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */     pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  89 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/*  92 */         new OutputConsole().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void appendText(String text) {
/*  98 */     this.jTextArea1.append(text);
/*  99 */     this.jTextArea1.selectAll();
/*     */     
/* 101 */     if (this.threadsUsing <= 0) {
/* 102 */       waitToDispose();
/*     */     }
/*     */   }
/*     */   
/*     */   public void acquire() {
/* 107 */     this.threadsUsing += 1;
/*     */   }
/*     */   
/*     */   public void release() {
/* 111 */     this.threadsUsing -= 1;
/* 112 */     if (this.threadsUsing <= 0) {
/* 113 */       waitToDispose();
/*     */     }
/*     */   }
/*     */   
/*     */   public void waitToDispose() {
/* 118 */     this.jTextArea1.append("\n\nThreads have Stopped... closing this window in 15 Seconds...\nIf you want to copy this, do it NOW!");
/*     */     try
/*     */     {
/* 121 */       Thread.sleep(15000L);
/*     */     }
/*     */     catch (InterruptedException ex) {}finally {
/* 124 */       dispose();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\anjocaido\console\OutputConsole.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */