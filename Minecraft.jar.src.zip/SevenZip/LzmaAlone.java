/*    */ package SevenZip;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ public class LzmaAlone {
/*  6 */   public static void decompress(File in, File out) throws Exception { File inFile = in;
/*  7 */     File outFile = out;
/*    */     
/*  9 */     java.io.BufferedInputStream inStream = new java.io.BufferedInputStream(new java.io.FileInputStream(inFile));
/* 10 */     java.io.BufferedOutputStream outStream = new java.io.BufferedOutputStream(new java.io.FileOutputStream(outFile));
/*    */     
/* 12 */     int propertiesSize = 5;
/* 13 */     byte[] properties = new byte[propertiesSize];
/* 14 */     if (inStream.read(properties, 0, propertiesSize) != propertiesSize) {
/* 15 */       throw new Exception("input .lzma file is too short");
/*    */     }
/* 17 */     SevenZip.Compression.LZMA.Decoder decoder = new SevenZip.Compression.LZMA.Decoder();
/* 18 */     if (!decoder.SetDecoderProperties(properties)) {
/* 19 */       throw new Exception("Incorrect stream properties");
/*    */     }
/* 21 */     long outSize = 0L;
/* 22 */     for (int i = 0; i < 8; i++) {
/* 23 */       int v = inStream.read();
/* 24 */       if (v < 0) {
/* 25 */         throw new Exception("Can't read stream size");
/*    */       }
/* 27 */       outSize |= v << 8 * i;
/*    */     }
/* 29 */     if (!decoder.Code(inStream, outStream, outSize)) {
/* 30 */       throw new Exception("Error in data stream");
/*    */     }
/*    */     
/* 33 */     outStream.flush();
/* 34 */     outStream.close();
/* 35 */     inStream.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\SevenZip\LzmaAlone.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */