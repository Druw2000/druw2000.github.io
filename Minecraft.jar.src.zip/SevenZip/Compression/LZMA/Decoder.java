/*     */ package SevenZip.Compression.LZMA;
/*     */ 
/*     */ import SevenZip.Compression.LZ.OutWindow;
/*     */ import SevenZip.Compression.RangeCoder.BitTreeDecoder;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class Decoder
/*     */ {
/*     */   class LenDecoder
/*     */   {
/*  12 */     short[] m_Choice = new short[2];
/*  13 */     BitTreeDecoder[] m_LowCoder = new BitTreeDecoder[16];
/*  14 */     BitTreeDecoder[] m_MidCoder = new BitTreeDecoder[16];
/*  15 */     BitTreeDecoder m_HighCoder = new BitTreeDecoder(8);
/*  16 */     int m_NumPosStates = 0;
/*     */     
/*     */     LenDecoder() {}
/*     */     
/*  20 */     public void Create(int numPosStates) { for (; this.m_NumPosStates < numPosStates; this.m_NumPosStates += 1)
/*     */       {
/*  22 */         this.m_LowCoder[this.m_NumPosStates] = new BitTreeDecoder(3);
/*  23 */         this.m_MidCoder[this.m_NumPosStates] = new BitTreeDecoder(3);
/*     */       }
/*     */     }
/*     */     
/*     */     public void Init()
/*     */     {
/*  29 */       SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_Choice);
/*  30 */       for (int posState = 0; posState < this.m_NumPosStates; posState++)
/*     */       {
/*  32 */         this.m_LowCoder[posState].Init();
/*  33 */         this.m_MidCoder[posState].Init();
/*     */       }
/*  35 */       this.m_HighCoder.Init();
/*     */     }
/*     */     
/*     */     public int Decode(SevenZip.Compression.RangeCoder.Decoder rangeDecoder, int posState) throws IOException
/*     */     {
/*  40 */       if (rangeDecoder.DecodeBit(this.m_Choice, 0) == 0)
/*  41 */         return this.m_LowCoder[posState].Decode(rangeDecoder);
/*  42 */       int symbol = 8;
/*  43 */       if (rangeDecoder.DecodeBit(this.m_Choice, 1) == 0) {
/*  44 */         symbol += this.m_MidCoder[posState].Decode(rangeDecoder);
/*     */       } else
/*  46 */         symbol += 8 + this.m_HighCoder.Decode(rangeDecoder);
/*  47 */       return symbol; } }
/*     */   
/*     */   class LiteralDecoder { Decoder2[] m_Coders;
/*     */     int m_NumPrevBits;
/*     */     int m_NumPosBits;
/*     */     int m_PosMask;
/*     */     LiteralDecoder() {}
/*     */     
/*  55 */     class Decoder2 { short[] m_Decoders = new short['̀'];
/*     */       
/*     */       Decoder2() {}
/*     */       
/*  59 */       public void Init() { SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_Decoders); }
/*     */       
/*     */       public byte DecodeNormal(SevenZip.Compression.RangeCoder.Decoder rangeDecoder)
/*     */         throws IOException
/*     */       {
/*  64 */         int symbol = 1;
/*     */         do {
/*  66 */           symbol = symbol << 1 | rangeDecoder.DecodeBit(this.m_Decoders, symbol);
/*  67 */         } while (symbol < 256);
/*  68 */         return (byte)symbol;
/*     */       }
/*     */       
/*     */       public byte DecodeWithMatchByte(SevenZip.Compression.RangeCoder.Decoder rangeDecoder, byte matchByte) throws IOException
/*     */       {
/*  73 */         int symbol = 1;
/*     */         do
/*     */         {
/*  76 */           int matchBit = matchByte >> 7 & 0x1;
/*  77 */           matchByte = (byte)(matchByte << 1);
/*  78 */           int bit = rangeDecoder.DecodeBit(this.m_Decoders, (1 + matchBit << 8) + symbol);
/*  79 */           symbol = symbol << 1 | bit;
/*  80 */           if (matchBit != bit)
/*     */           {
/*  82 */             while (symbol < 256) {
/*  83 */               symbol = symbol << 1 | rangeDecoder.DecodeBit(this.m_Decoders, symbol);
/*     */             }
/*     */             
/*     */           }
/*  87 */         } while (symbol < 256);
/*  88 */         return (byte)symbol;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void Create(int numPosBits, int numPrevBits)
/*     */     {
/*  99 */       if ((this.m_Coders != null) && (this.m_NumPrevBits == numPrevBits) && (this.m_NumPosBits == numPosBits))
/* 100 */         return;
/* 101 */       this.m_NumPosBits = numPosBits;
/* 102 */       this.m_PosMask = ((1 << numPosBits) - 1);
/* 103 */       this.m_NumPrevBits = numPrevBits;
/* 104 */       int numStates = 1 << this.m_NumPrevBits + this.m_NumPosBits;
/* 105 */       this.m_Coders = new Decoder2[numStates];
/* 106 */       for (int i = 0; i < numStates; i++) {
/* 107 */         this.m_Coders[i] = new Decoder2();
/*     */       }
/*     */     }
/*     */     
/*     */     public void Init() {
/* 112 */       int numStates = 1 << this.m_NumPrevBits + this.m_NumPosBits;
/* 113 */       for (int i = 0; i < numStates; i++) {
/* 114 */         this.m_Coders[i].Init();
/*     */       }
/*     */     }
/*     */     
/*     */     Decoder2 GetDecoder(int pos, byte prevByte) {
/* 119 */       return this.m_Coders[(((pos & this.m_PosMask) << this.m_NumPrevBits) + ((prevByte & 0xFF) >>> 8 - this.m_NumPrevBits))];
/*     */     }
/*     */   }
/*     */   
/* 123 */   OutWindow m_OutWindow = new OutWindow();
/* 124 */   SevenZip.Compression.RangeCoder.Decoder m_RangeDecoder = new SevenZip.Compression.RangeCoder.Decoder();
/*     */   
/* 126 */   short[] m_IsMatchDecoders = new short['À'];
/* 127 */   short[] m_IsRepDecoders = new short[12];
/* 128 */   short[] m_IsRepG0Decoders = new short[12];
/* 129 */   short[] m_IsRepG1Decoders = new short[12];
/* 130 */   short[] m_IsRepG2Decoders = new short[12];
/* 131 */   short[] m_IsRep0LongDecoders = new short['À'];
/*     */   
/* 133 */   BitTreeDecoder[] m_PosSlotDecoder = new BitTreeDecoder[4];
/* 134 */   short[] m_PosDecoders = new short[114];
/*     */   
/* 136 */   BitTreeDecoder m_PosAlignDecoder = new BitTreeDecoder(4);
/*     */   
/* 138 */   LenDecoder m_LenDecoder = new LenDecoder();
/* 139 */   LenDecoder m_RepLenDecoder = new LenDecoder();
/*     */   
/* 141 */   LiteralDecoder m_LiteralDecoder = new LiteralDecoder();
/*     */   
/* 143 */   int m_DictionarySize = -1;
/* 144 */   int m_DictionarySizeCheck = -1;
/*     */   
/*     */   int m_PosStateMask;
/*     */   
/*     */   public Decoder()
/*     */   {
/* 150 */     for (int i = 0; i < 4; i++) {
/* 151 */       this.m_PosSlotDecoder[i] = new BitTreeDecoder(6);
/*     */     }
/*     */   }
/*     */   
/*     */   boolean SetDictionarySize(int dictionarySize) {
/* 156 */     if (dictionarySize < 0)
/* 157 */       return false;
/* 158 */     if (this.m_DictionarySize != dictionarySize)
/*     */     {
/* 160 */       this.m_DictionarySize = dictionarySize;
/* 161 */       this.m_DictionarySizeCheck = Math.max(this.m_DictionarySize, 1);
/* 162 */       this.m_OutWindow.Create(Math.max(this.m_DictionarySizeCheck, 4096));
/*     */     }
/* 164 */     return true;
/*     */   }
/*     */   
/*     */   boolean SetLcLpPb(int lc, int lp, int pb)
/*     */   {
/* 169 */     if ((lc > 8) || (lp > 4) || (pb > 4))
/* 170 */       return false;
/* 171 */     this.m_LiteralDecoder.Create(lp, lc);
/* 172 */     int numPosStates = 1 << pb;
/* 173 */     this.m_LenDecoder.Create(numPosStates);
/* 174 */     this.m_RepLenDecoder.Create(numPosStates);
/* 175 */     this.m_PosStateMask = (numPosStates - 1);
/* 176 */     return true;
/*     */   }
/*     */   
/*     */   void Init() throws IOException
/*     */   {
/* 181 */     this.m_OutWindow.Init(false);
/*     */     
/* 183 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_IsMatchDecoders);
/* 184 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_IsRep0LongDecoders);
/* 185 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_IsRepDecoders);
/* 186 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_IsRepG0Decoders);
/* 187 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_IsRepG1Decoders);
/* 188 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_IsRepG2Decoders);
/* 189 */     SevenZip.Compression.RangeCoder.Decoder.InitBitModels(this.m_PosDecoders);
/*     */     
/* 191 */     this.m_LiteralDecoder.Init();
/*     */     
/* 193 */     for (int i = 0; i < 4; i++)
/* 194 */       this.m_PosSlotDecoder[i].Init();
/* 195 */     this.m_LenDecoder.Init();
/* 196 */     this.m_RepLenDecoder.Init();
/* 197 */     this.m_PosAlignDecoder.Init();
/* 198 */     this.m_RangeDecoder.Init();
/*     */   }
/*     */   
/*     */   public boolean Code(java.io.InputStream inStream, OutputStream outStream, long outSize)
/*     */     throws IOException
/*     */   {
/* 204 */     this.m_RangeDecoder.SetStream(inStream);
/* 205 */     this.m_OutWindow.SetStream(outStream);
/* 206 */     Init();
/*     */     
/* 208 */     int state = Base.StateInit();
/* 209 */     int rep0 = 0;int rep1 = 0;int rep2 = 0;int rep3 = 0;
/*     */     
/* 211 */     long nowPos64 = 0L;
/* 212 */     byte prevByte = 0;
/* 213 */     while ((outSize < 0L) || (nowPos64 < outSize))
/*     */     {
/* 215 */       int posState = (int)nowPos64 & this.m_PosStateMask;
/* 216 */       if (this.m_RangeDecoder.DecodeBit(this.m_IsMatchDecoders, (state << 4) + posState) == 0)
/*     */       {
/* 218 */         Decoder.LiteralDecoder.Decoder2 decoder2 = this.m_LiteralDecoder.GetDecoder((int)nowPos64, prevByte);
/* 219 */         if (!Base.StateIsCharState(state)) {
/* 220 */           prevByte = decoder2.DecodeWithMatchByte(this.m_RangeDecoder, this.m_OutWindow.GetByte(rep0));
/*     */         } else
/* 222 */           prevByte = decoder2.DecodeNormal(this.m_RangeDecoder);
/* 223 */         this.m_OutWindow.PutByte(prevByte);
/* 224 */         state = Base.StateUpdateChar(state);
/* 225 */         nowPos64 += 1L;
/*     */       }
/*     */       else
/*     */       {
/*     */         int len;
/* 230 */         if (this.m_RangeDecoder.DecodeBit(this.m_IsRepDecoders, state) == 1)
/*     */         {
/* 232 */           int len = 0;
/* 233 */           if (this.m_RangeDecoder.DecodeBit(this.m_IsRepG0Decoders, state) == 0)
/*     */           {
/* 235 */             if (this.m_RangeDecoder.DecodeBit(this.m_IsRep0LongDecoders, (state << 4) + posState) == 0)
/*     */             {
/* 237 */               state = Base.StateUpdateShortRep(state);
/* 238 */               len = 1;
/*     */             }
/*     */           }
/*     */           else {
/*     */             int distance;
/*     */             int distance;
/* 244 */             if (this.m_RangeDecoder.DecodeBit(this.m_IsRepG1Decoders, state) == 0) {
/* 245 */               distance = rep1;
/*     */             } else {
/*     */               int distance;
/* 248 */               if (this.m_RangeDecoder.DecodeBit(this.m_IsRepG2Decoders, state) == 0) {
/* 249 */                 distance = rep2;
/*     */               }
/*     */               else {
/* 252 */                 distance = rep3;
/* 253 */                 rep3 = rep2;
/*     */               }
/* 255 */               rep2 = rep1;
/*     */             }
/* 257 */             rep1 = rep0;
/* 258 */             rep0 = distance;
/*     */           }
/* 260 */           if (len == 0)
/*     */           {
/* 262 */             len = this.m_RepLenDecoder.Decode(this.m_RangeDecoder, posState) + 2;
/* 263 */             state = Base.StateUpdateRep(state);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 268 */           rep3 = rep2;
/* 269 */           rep2 = rep1;
/* 270 */           rep1 = rep0;
/* 271 */           len = 2 + this.m_LenDecoder.Decode(this.m_RangeDecoder, posState);
/* 272 */           state = Base.StateUpdateMatch(state);
/* 273 */           int posSlot = this.m_PosSlotDecoder[Base.GetLenToPosState(len)].Decode(this.m_RangeDecoder);
/* 274 */           if (posSlot >= 4)
/*     */           {
/* 276 */             int numDirectBits = (posSlot >> 1) - 1;
/* 277 */             rep0 = (0x2 | posSlot & 0x1) << numDirectBits;
/* 278 */             if (posSlot < 14) {
/* 279 */               rep0 += BitTreeDecoder.ReverseDecode(this.m_PosDecoders, rep0 - posSlot - 1, this.m_RangeDecoder, numDirectBits);
/*     */             }
/*     */             else
/*     */             {
/* 283 */               rep0 += (this.m_RangeDecoder.DecodeDirectBits(numDirectBits - 4) << 4);
/*     */               
/* 285 */               rep0 += this.m_PosAlignDecoder.ReverseDecode(this.m_RangeDecoder);
/* 286 */               if (rep0 < 0)
/*     */               {
/* 288 */                 if (rep0 == -1)
/*     */                   break;
/* 290 */                 return false;
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 295 */             rep0 = posSlot;
/*     */           } }
/* 297 */         if ((rep0 >= nowPos64) || (rep0 >= this.m_DictionarySizeCheck))
/*     */         {
/*     */ 
/* 300 */           return false;
/*     */         }
/* 302 */         this.m_OutWindow.CopyBlock(rep0, len);
/* 303 */         nowPos64 += len;
/* 304 */         prevByte = this.m_OutWindow.GetByte(0);
/*     */       }
/*     */     }
/* 307 */     this.m_OutWindow.Flush();
/* 308 */     this.m_OutWindow.ReleaseStream();
/* 309 */     this.m_RangeDecoder.ReleaseStream();
/* 310 */     return true;
/*     */   }
/*     */   
/*     */   public boolean SetDecoderProperties(byte[] properties)
/*     */   {
/* 315 */     if (properties.length < 5)
/* 316 */       return false;
/* 317 */     int val = properties[0] & 0xFF;
/* 318 */     int lc = val % 9;
/* 319 */     int remainder = val / 9;
/* 320 */     int lp = remainder % 5;
/* 321 */     int pb = remainder / 5;
/* 322 */     int dictionarySize = 0;
/* 323 */     for (int i = 0; i < 4; i++)
/* 324 */       dictionarySize += ((properties[(1 + i)] & 0xFF) << i * 8);
/* 325 */     if (!SetLcLpPb(lc, lp, pb))
/* 326 */       return false;
/* 327 */     return SetDictionarySize(dictionarySize);
/*     */   }
/*     */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\SevenZip\Compression\LZMA\Decoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */