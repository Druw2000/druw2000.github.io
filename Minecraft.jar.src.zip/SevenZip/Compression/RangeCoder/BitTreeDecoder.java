/*    */ package SevenZip.Compression.RangeCoder;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class BitTreeDecoder {
/*    */   short[] Models;
/*    */   int NumBitLevels;
/*    */   
/*    */   public BitTreeDecoder(int numBitLevels) {
/* 10 */     this.NumBitLevels = numBitLevels;
/* 11 */     this.Models = new short[1 << numBitLevels];
/*    */   }
/*    */   
/*    */   public void Init()
/*    */   {
/* 16 */     Decoder.InitBitModels(this.Models);
/*    */   }
/*    */   
/*    */   public int Decode(Decoder rangeDecoder) throws IOException
/*    */   {
/* 21 */     int m = 1;
/* 22 */     for (int bitIndex = this.NumBitLevels; bitIndex != 0; bitIndex--)
/* 23 */       m = (m << 1) + rangeDecoder.DecodeBit(this.Models, m);
/* 24 */     return m - (1 << this.NumBitLevels);
/*    */   }
/*    */   
/*    */   public int ReverseDecode(Decoder rangeDecoder) throws IOException
/*    */   {
/* 29 */     int m = 1;
/* 30 */     int symbol = 0;
/* 31 */     for (int bitIndex = 0; bitIndex < this.NumBitLevels; bitIndex++)
/*    */     {
/* 33 */       int bit = rangeDecoder.DecodeBit(this.Models, m);
/* 34 */       m <<= 1;
/* 35 */       m += bit;
/* 36 */       symbol |= bit << bitIndex;
/*    */     }
/* 38 */     return symbol;
/*    */   }
/*    */   
/*    */   public static int ReverseDecode(short[] Models, int startIndex, Decoder rangeDecoder, int NumBitLevels)
/*    */     throws IOException
/*    */   {
/* 44 */     int m = 1;
/* 45 */     int symbol = 0;
/* 46 */     for (int bitIndex = 0; bitIndex < NumBitLevels; bitIndex++)
/*    */     {
/* 48 */       int bit = rangeDecoder.DecodeBit(Models, startIndex + m);
/* 49 */       m <<= 1;
/* 50 */       m += bit;
/* 51 */       symbol |= bit << bitIndex;
/*    */     }
/* 53 */     return symbol;
/*    */   }
/*    */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\SevenZip\Compression\RangeCoder\BitTreeDecoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */