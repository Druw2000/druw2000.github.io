/*    */ package SevenZip.Compression.RangeCoder;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ public class Decoder
/*    */ {
/*    */   static final int kTopMask = -16777216;
/*    */   static final int kNumBitModelTotalBits = 11;
/*    */   static final int kBitModelTotal = 2048;
/*    */   static final int kNumMoveBits = 5;
/*    */   int Range;
/*    */   int Code;
/*    */   InputStream Stream;
/*    */   
/*    */   public final void SetStream(InputStream stream)
/*    */   {
/* 19 */     this.Stream = stream;
/*    */   }
/*    */   
/*    */   public final void ReleaseStream()
/*    */   {
/* 24 */     this.Stream = null;
/*    */   }
/*    */   
/*    */   public final void Init() throws IOException
/*    */   {
/* 29 */     this.Code = 0;
/* 30 */     this.Range = -1;
/* 31 */     for (int i = 0; i < 5; i++) {
/* 32 */       this.Code = (this.Code << 8 | this.Stream.read());
/*    */     }
/*    */   }
/*    */   
/*    */   public final int DecodeDirectBits(int numTotalBits) throws IOException {
/* 37 */     int result = 0;
/* 38 */     for (int i = numTotalBits; i != 0; i--)
/*    */     {
/* 40 */       this.Range >>>= 1;
/* 41 */       int t = this.Code - this.Range >>> 31;
/* 42 */       this.Code -= (this.Range & t - 1);
/* 43 */       result = result << 1 | 1 - t;
/*    */       
/* 45 */       if ((this.Range & 0xFF000000) == 0)
/*    */       {
/* 47 */         this.Code = (this.Code << 8 | this.Stream.read());
/* 48 */         this.Range <<= 8;
/*    */       }
/*    */     }
/* 51 */     return result;
/*    */   }
/*    */   
/*    */   public int DecodeBit(short[] probs, int index) throws IOException
/*    */   {
/* 56 */     int prob = probs[index];
/* 57 */     int newBound = (this.Range >>> 11) * prob;
/* 58 */     if ((this.Code ^ 0x80000000) < (newBound ^ 0x80000000))
/*    */     {
/* 60 */       this.Range = newBound;
/* 61 */       probs[index] = ((short)(prob + (2048 - prob >>> 5)));
/* 62 */       if ((this.Range & 0xFF000000) == 0)
/*    */       {
/* 64 */         this.Code = (this.Code << 8 | this.Stream.read());
/* 65 */         this.Range <<= 8;
/*    */       }
/* 67 */       return 0;
/*    */     }
/*    */     
/*    */ 
/* 71 */     this.Range -= newBound;
/* 72 */     this.Code -= newBound;
/* 73 */     probs[index] = ((short)(prob - (prob >>> 5)));
/* 74 */     if ((this.Range & 0xFF000000) == 0)
/*    */     {
/* 76 */       this.Code = (this.Code << 8 | this.Stream.read());
/* 77 */       this.Range <<= 8;
/*    */     }
/* 79 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */   public static void InitBitModels(short[] probs)
/*    */   {
/* 85 */     for (int i = 0; i < probs.length; i++) {
/* 86 */       probs[i] = 1024;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\SevenZip\Compression\RangeCoder\Decoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */