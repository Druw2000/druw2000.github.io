/*    */ package SevenZip.Compression.LZ;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ public class OutWindow
/*    */ {
/*    */   byte[] _buffer;
/*    */   int _pos;
/* 11 */   int _windowSize = 0;
/*    */   int _streamPos;
/*    */   OutputStream _stream;
/*    */   
/*    */   public void Create(int windowSize)
/*    */   {
/* 17 */     if ((this._buffer == null) || (this._windowSize != windowSize))
/* 18 */       this._buffer = new byte[windowSize];
/* 19 */     this._windowSize = windowSize;
/* 20 */     this._pos = 0;
/* 21 */     this._streamPos = 0;
/*    */   }
/*    */   
/*    */   public void SetStream(OutputStream stream) throws IOException
/*    */   {
/* 26 */     ReleaseStream();
/* 27 */     this._stream = stream;
/*    */   }
/*    */   
/*    */   public void ReleaseStream() throws IOException
/*    */   {
/* 32 */     Flush();
/* 33 */     this._stream = null;
/*    */   }
/*    */   
/*    */   public void Init(boolean solid)
/*    */   {
/* 38 */     if (!solid)
/*    */     {
/* 40 */       this._streamPos = 0;
/* 41 */       this._pos = 0;
/*    */     }
/*    */   }
/*    */   
/*    */   public void Flush() throws IOException
/*    */   {
/* 47 */     int size = this._pos - this._streamPos;
/* 48 */     if (size == 0)
/* 49 */       return;
/* 50 */     this._stream.write(this._buffer, this._streamPos, size);
/* 51 */     if (this._pos >= this._windowSize)
/* 52 */       this._pos = 0;
/* 53 */     this._streamPos = this._pos;
/*    */   }
/*    */   
/*    */   public void CopyBlock(int distance, int len) throws IOException
/*    */   {
/* 58 */     int pos = this._pos - distance - 1;
/* 59 */     if (pos < 0)
/* 60 */       pos += this._windowSize;
/* 61 */     for (; len != 0; len--)
/*    */     {
/* 63 */       if (pos >= this._windowSize)
/* 64 */         pos = 0;
/* 65 */       this._buffer[(this._pos++)] = this._buffer[(pos++)];
/* 66 */       if (this._pos >= this._windowSize) {
/* 67 */         Flush();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void PutByte(byte b) throws IOException {
/* 73 */     this._buffer[(this._pos++)] = b;
/* 74 */     if (this._pos >= this._windowSize) {
/* 75 */       Flush();
/*    */     }
/*    */   }
/*    */   
/*    */   public byte GetByte(int distance) {
/* 80 */     int pos = this._pos - distance - 1;
/* 81 */     if (pos < 0)
/* 82 */       pos += this._windowSize;
/* 83 */     return this._buffer[pos];
/*    */   }
/*    */ }


/* Location:              C:\Users\19andruwnearnhardt\Downloads\Minecraft.jar!\SevenZip\Compression\LZ\OutWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */